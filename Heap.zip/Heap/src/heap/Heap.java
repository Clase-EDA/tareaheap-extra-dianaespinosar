
package heap;


public class Heap<T extends Comparable<T>> {

    public T[] heap;
    private int cant;

    public Heap(int tamaño) {
        this.cant = 0;
        heap = (T[]) (new Comparable[tamaño + 1]); 
        //tamaño es la cantidad de datos
        //que se van a guardar. La celda 0 va vacía. 
        heap[0] = null;
    }

    
    public T getMin(){
        return heap[1];
    }
    
    public int getPapa(int pos){
        return pos/2; 
    }
    //Hijo Izq
    public int getIzq(int pos){
        return 2*pos; 
    }
    //Hijo Derecho
    public int getDer(int pos){
        return 2*pos + 1; 
    }

    public int getCant() {
        return cant;
    }
    
    
    public void insertar(T nuevo){
       
        if((cant + 2) >=  heap.length){
            
            T[] aux = (T[]) (new Comparable[heap.length * 2]);
            System.arraycopy(heap, 0, aux, 0, cant + 1);
            heap = aux;
           
        }
      
        if(nuevo != null ){
            
            heap[cant + 1] = nuevo;

            int j = cant+1;
            T aux;
            
            int posPap = getPapa(j);
            

            if(posPap != 0 && heap[j].compareTo(heap[posPap]) < 0){
                
                while( posPap != 0 && heap[j].compareTo(heap[posPap]) < 0 ){
                    swap(posPap,(j));
                    j = posPap;
                    posPap = getPapa(j);
                }
            }
            cant++;
            
        }
    }
    
    public T eliminarMin(){
        T aux = heap[1];
        
        heap[1] = heap[cant];
        
        heap[cant] = null;
        cant--;
        eliminarMin(1);
        return aux;
    }
    
    private void eliminarMin(int act){
        
        int izq = getIzq(act);
        int der = getDer(act);
        if(izq > heap.length || heap[izq] == null){
           
            return;
        }
       
        if(der > cant ){
            
            if(heap[act].compareTo(heap[izq]) > 0){
                swap(izq,act);
                eliminarMin(izq);
                
            }
            return;
        }
       
        if(heap[act].compareTo(heap[izq]) > 0  && heap[act].compareTo(heap[der]) > 0){
            
            if( heap[izq].compareTo(heap[der]) > 0){
                swap(der,act);
                eliminarMin(der);
            }
            else{
                swap(izq,act);
                eliminarMin(izq);
            }
        }
        else if(heap[act].compareTo(heap[izq]) > 0){
            swap(izq,act);
            eliminarMin(izq);
        }
        else if( heap[act].compareTo(heap[der]) > 0){
            swap(der,act);
            eliminarMin(der);
        }
    }
        
    
    public void swap(int a, int b){
        T aux =  heap[a];
        heap[a] = heap[b];
        heap[b] = aux;
    }
    
    public <T extends Comparable<T>> T[] heapSort() {
        
        T[] res = (T[]) (new Comparable[cant]);
        int i = 0;
        while (cant != 0) {
           
            Object elem = eliminarMin();
            
            if (elem != null) {
                res[i] = (T) elem;
                i++;
            }
        }
        return res;
    }
    
    public void imprime() {
        for (int i = 1; i <= cant / 2; i++) {
            System.out.print(" Papá : " + heap[i]
                    + " Izquierdo : " + heap[2 * i]
                    + " Derecho :" + heap[2 * i + 1]);
            System.out.println();
        }
    }
    
    public static void main(String[] args) {
        
        Heap<String> minHeap = new Heap(10);
        minHeap.insertar("Diana");
        minHeap.imprime();
        
        minHeap.insertar("Elisa");
        minHeap.imprime();
        minHeap.insertar("DE");
        minHeap.imprime();
        minHeap.insertar("Ana");
        System.out.println("más pequeño es " + minHeap.getMin());
        System.out.println(minHeap.getCant());
        minHeap.imprime();
        minHeap.insertar("Blanca");
        minHeap.insertar("Fabiola");
        minHeap.insertar("Carlota");
        minHeap.insertar("Gaby");
        minHeap.insertar(("Abi"));
        minHeap.insertar("Ricardo");
        minHeap.insertar("Moana");
        minHeap.insertar("Jazmin");
        minHeap.insertar("Hans");
        minHeap.insertar(("Susy"));
        minHeap.eliminarMin();
        minHeap.imprime();
        minHeap.eliminarMin();
        minHeap.eliminarMin();
        minHeap.eliminarMin();
    }
    

}
