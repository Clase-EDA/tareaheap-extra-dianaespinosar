
package heap;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Arrays;
import java.util.Scanner;
import java.text.Normalizer;
import static javafx.scene.input.KeyCode.T;

public class Pruebas <T> {
    public static String cleanString(String texto) {
        texto = Normalizer.normalize(texto, Normalizer.Form.NFD);
        texto = texto.replaceAll("[\\p{InCombiningDiacriticalMarks}]", "");
        return texto;
    }
    
    public static void main(String[] args) {
        
        Scanner sc = null;
        String[] lista = new String[90000], aux;
        int i = 0;
        boolean ban;
        long TInicio, TFin, tiempo;
        try {
            File file = new File("wiki-100k.txt");
            Scanner leeArch = new Scanner(file);
            String palabra;
            palabra = leeArch.nextLine();
            palabra = palabra.substring(1);
            while (i < 55000) {
                palabra = leeArch.nextLine();
                palabra = cleanString(palabra);
                if((palabra.contains("'") || palabra.contains("#") || palabra.contains(" ") || palabra.contains("©") || palabra.contains("æ") || palabra.contains("«") || palabra.contains("ß") ||palabra.contains("Ã") ||palabra.contains(".") ||palabra.contains("-") ||palabra.contains("¹") ||palabra.contains("å") ||palabra.contains("¿") ||palabra.contains("ö") ||palabra.contains("ø") ||palabra.contains("þ") ||palabra.contains("¡") ||palabra.contains("ª") ||palabra.contains(":") ||palabra.contains("¨") ||palabra.contains("»") ||palabra.contains("§") ||palabra.contains("º") ||palabra.contains("±") ||palabra.contains("¦") ||palabra.contains("ð")))
                   palabra = "";
                else{
                   // System.out.print("\n imoprimr: " + palabra);
                   if(palabra!= null)
                        lista[i] = palabra;
                }
                i++;
            }
            leeArch.close();
            
        } catch (Exception e) {
           throw new NullPointerException("Error"); 
        }
        
        
        //Heap-Sort
        int tam = i-1;
        double prom=0; 
        int cont = 0;
        for(int k=0; k<100; k++){
            Heap<String> minHeap = new Heap(5000);
            TInicio = System.currentTimeMillis();
            for (int j = 0; j < tam+1; j++) {

                minHeap.insertar(lista[j]);

            }

            Object[] res3 =  minHeap.heapSort();
            TFin = System.currentTimeMillis();
            tiempo = TFin - TInicio;
            prom+=tiempo;
            minHeap.imprime();

            }
        System.out.print("Tiempo promedio en Heap: ");
        System.out.println(prom/100.0);
        
        
       
    }
}
